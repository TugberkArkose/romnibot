This is version 1.4 of Messenger
You can find the documentation here: http://www.arduino.cc/playground/Code/Messenger

I prefer you try to contact me through the following thread on the Arduino forums:
http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1222259218/8
But if I do not answer, you can email me with questions here: mrtoftrash@gmail.com
